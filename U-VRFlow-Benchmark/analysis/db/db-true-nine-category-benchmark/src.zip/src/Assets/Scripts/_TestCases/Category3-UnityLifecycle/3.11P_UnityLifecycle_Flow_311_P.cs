using UnityEngine;
using System.IO;

/// INTEGRATED CATEGORY: Category3-UnityLifecycle
/// LEGACY CASE: Category1-Lifecycle/1.11P
/// EXPECTED: TRUE POSITIVE
public class UnityLifecycle_StartUpdate_311_P : MonoBehaviour
{
    private string _payload_311_P;
    private bool f2 = false;
    private bool f3 = false;
    void Awake()
    {
        _payload_311_P = TestSources.GetNetworkInput();

        // 3. 【规则 5 的博弈点】
        // 如果在此处直接写：f = "final_clean_data"; 则触发规则 5，漏洞在该方法出口被强行拦截。
        // 但由于开发者漏掉了对 else 分支的处理，或者在这里写了自污染语句（如 f = f + "id";），
        // 导致没有一个“确定性的、排在最后的、非自引用的覆盖写 w_over”能够支配整个出口。
        // 结论：规则 5 判定拦截失败（IsIntercepted = 假），污点包裹顺利从 Awake 出库！
    }

    void Update()
    {
        // 路径分支 𝝿_A：
        if (f2)
        {
            _payload_311_P = "calibrated_safe_stream";
            TestSinks.DangerousLoad(_payload_311_P);
        }
        // 路径分支 𝝿_B：
        else if (f3)
        {

            SanitizeSystemField();
            TestSinks.DangerousLoad(_payload_311_P);
        }
        // 路径分支 𝝿_C (隐式 else 分支)：
        else
        {
            // 关键缺陷：开发者在此分支内完全忘记了对 f 的处理！
            // 字段 f 保持了从 Awake 漂流过来的原始恶意污点。
        }

        // ─── 🛑 终点控制流汇聚关卡 ───

        // 消费点 3 (Sink 3)
        TestSinks.DangerousLoad(_payload_311_P);
    }

    private void SanitizeSystemField()
    {
        _payload_311_P = "fallback_safe_stream";
    }
}
